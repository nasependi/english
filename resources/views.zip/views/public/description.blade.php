<html>
<head>
<link crossorigin="" href="https://fonts.gstatic.com/" rel="preconnect"/>
<link as="style" href="https://fonts.googleapis.com/css2?display=swap&amp;family=Lexend%3Awght%40400%3B500%3B700%3B900&amp;family=Noto+Sans%3Awght%40400%3B500%3B700%3B900" onload="this.rel='stylesheet'" rel="stylesheet"/>
<meta charset="utf-8"/>
<title>EduQuest - Gerak Lurus</title>
<link href="data:image/x-icon;base64," rel="icon" type="image/x-icon"/>
<script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
<style type="text/tailwindcss">
      :root {
        --primary-color: #3d98f4;
        --secondary-color: #f0f2f5;
        --text-primary: #111418;
        --text-secondary: #60758a;
        --border-color: #dbe0e6;
      }
      .nav-link-active {
        color: var(--primary-color);
        font-weight: 700;
      }
      .nav-link:hover {
        color: var(--primary-color);
      }
</style>
</head>
<body class="bg-white" style='font-family: Lexend, "Noto Sans", sans-serif;'>
<div class="relative flex size-full min-h-screen flex-col group/design-root overflow-x-hidden">
	<div class="layout-container flex h-full grow flex-col">
		<header class="flex items-center justify-between whitespace-nowrap border-b border-solid border-b-[var(--border-color)] px-10 py-4 shadow-sm">
		<div class="flex items-center gap-4 text-[var(--text-primary)]">
			<div class="size-6 text-[var(--primary-color)]">
				<svg fill="none" viewbox="0 0 48 48" xmlns="http://www.w3.org/2000/svg"><path d="M44 4H30.6666V17.3334H17.3334V30.6666H4V44H44V4Z" fill="currentColor"></path></svg>
			</div>
			<h1 class="text-[var(--text-primary)] text-xl font-bold leading-tight tracking-[-0.015em]">EduQuest</h1>
		</div>
		<nav class="hidden md:flex items-center gap-8">
		<a class="text-[var(--text-primary)] hover:text-[var(--primary-color)] text-sm font-medium leading-normal py-2 transition-colors" href="landing-page.html">Home</a>
		<a class="nav-link-active text-sm font-medium leading-normal py-2 transition-colors" href="chapter.html">Chapter</a>
		<a class="text-[var(--text-primary)] hover:text-[var(--primary-color)] text-sm font-medium leading-normal py-2 transition-colors" href="quiz.html">Quiz</a>
		<a class="text-[var(--text-primary)] hover:text-[var(--primary-color)] text-sm font-medium leading-normal py-2 transition-colors" href="score.html">Score</a>
		</nav>
		</nav>
		<div class="flex items-center gap-4">
			<button aria-label="Notifikasi" class="flex max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-full h-10 w-10 bg-[var(--secondary-color)] text-[var(--text-primary)] hover:bg-gray-200 transition-colors duration-150">
			<div class="text-[var(--text-primary)]" data-icon="Bell" data-size="24px" data-weight="regular">
				<svg fill="currentColor" height="24px" viewbox="0 0 256 256" width="24px" xmlns="http://www.w3.org/2000/svg">
				<path d="M221.8,175.94C216.25,166.38,208,139.33,208,104a80,80,0,1,0-160,0c0,35.34-8.26,62.38-13.81,71.94A16,16,0,0,0,48,200H88.81a40,40,0,0,0,78.38,0H208a16,16,0,0,0,13.8-24.06ZM128,216a24,24,0,0,1-22.62-16h45.24A24,24,0,0,1,128,216ZM48,184c7.7-13.24,16-43.92,16-80a64,64,0,1,1,128,0c0,36.05,8.28,66.73,16,80Z"></path>
				</svg>
			</div>
			</button>
			<div class="bg-center bg-no-repeat aspect-square bg-cover rounded-full size-10 border border-gray-300" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuAV0N_LbqnDnx2P3EjD6DzfHoQ2IVjBILQdEridM3RLpCOr4-3IEMWi-m9jYef7nFhrEmCOhHZDM1drz9p6Z5V2jGgZBnBCV9rWEhFpZYduxCzMqLCgM5tsEDd6gFvbyOaiIrKY5Fw-gSoNNc-rRWxtl48IliSB3w9JqEfqm2-ABi8CRdGZWIDA6yrtWjCiv0BYeJBOHBTliquqETqlY49YkpESZpmPr85i1yRIXgxeGF6cMThBo2mi7GNydHXpnmtgbeTfsyj7fJmy");'>
			</div>
		</div>
		</header>
		<main class="px-10 sm:px-20 md:px-40 flex flex-1 justify-center py-8 bg-slate-50">
		<div class="layout-content-container flex flex-col max-w-4xl flex-1 bg-white p-8 rounded-lg shadow-lg">
			<nav aria-label="Breadcrumb" class="mb-6">
			<ol class="flex flex-wrap items-center gap-2 text-sm">
				<li>
					<a class="text-[var(--text-secondary)] hover:text-[var(--primary-color)] transition-colors duration-150 font-medium" href="#">Kelas 10</a>
				</li>
				<li>
					<span class="text-[var(--text-secondary)]">/</span>
				</li>
				<li>
					<a class="text-[var(--text-secondary)] hover:text-[var(--primary-color)] transition-colors duration-150 font-medium" href="#">Bahasa Inggris</a>
				</li>
			</ol>
			</nav>
			<article>
			<h2 class="text-[var(--text-primary)] tracking-tight text-3xl font-bold leading-tight mb-6">About what?</h2>
			<p class="text-[var(--text-primary)] text-base font-normal leading-relaxed mb-6">
				 Gerak lurus adalah jenis gerak yang paling sederhana. Dalam gerak ini, suatu benda bergerak sepanjang garis lurus. Kecepatan benda dapat konstan atau berubah. Jika kecepatan konstan, gerak tersebut disebut gerak lurus beraturan (GLB). Jika kecepatan berubah, gerak tersebut disebut gerak lurus berubah beraturan (GLBB).
			</p>
			<section class="mb-8">
			<h3 class="text-[var(--text-primary)] text-xl font-bold leading-tight tracking-[-0.015em] mb-4">Konsep Dasar</h3>
			<p class="text-[var(--text-primary)] text-base font-normal leading-relaxed">
				 Kecepatan adalah perubahan posisi per satuan waktu. Percepatan adalah perubahan kecepatan per satuan waktu. Dalam GLB, percepatan adalah nol. Dalam GLBB, percepatan adalah konstan.
			</p>
			</section>
			<section class="mb-8">
			<h3 class="text-[var(--text-primary)] text-xl font-bold leading-tight tracking-[-0.015em] mb-4">Rumus-Rumus</h3>
			<div class="border border-[var(--border-color)] rounded-md overflow-hidden">
				<table class="w-full text-sm">
				<thead class="bg-slate-100">
				<tr>
					<th class="text-left p-4 font-semibold text-[var(--text-primary)] w-2/5">Besaran</th>
					<th class="text-left p-4 font-semibold text-[var(--text-primary)]">Rumus</th>
				</tr>
				</thead>
				<tbody>
				<tr class="border-t border-[var(--border-color)]">
					<td class="p-4 text-[var(--text-secondary)]">Kecepatan (v)</td>
					<td class="p-4 text-[var(--text-primary)] font-medium">
						<code>v = s / t</code>
					</td>
				</tr>
				<tr class="border-t border-[var(--border-color)] bg-slate-50">
					<td class="p-4 text-[var(--text-secondary)]">Percepatan (a)</td>
					<td class="p-4 text-[var(--text-primary)] font-medium">
						<code>a = (v<sub>akhir</sub> - v<sub>awal</sub>) / t</code>
					</td>
				</tr>
				<tr class="border-t border-[var(--border-color)]">
					<td class="p-4 text-[var(--text-secondary)]">Waktu (t)</td>
					<td class="p-4 text-[var(--text-primary)] font-medium">
						<code>t = s / v</code>
					</td>
				</tr>
				<tr class="border-t border-[var(--border-color)] bg-slate-50">
					<td class="p-4 text-[var(--text-secondary)]">Jarak (s)</td>
					<td class="p-4 text-[var(--text-primary)] font-medium">
						<code>s = v * t</code>
					</td>
				</tr>
				</tbody>
				</table>
			</div>
			</section>
			</article>
			<div class="flex justify-end mt-8">
				<button class="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-12 px-6 bg-[var(--primary-color)] text-white text-base font-bold leading-normal tracking-[0.015em] hover:bg-blue-600 transition-colors duration-150 shadow-md hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-opacity-75">
				<span class="truncate">Mulai Kuis</span>
				<svg class="ml-2" fill="currentColor" height="20" viewbox="0 0 256 256" width="20" xmlns="http://www.w3.org/2000/svg">
				<path d="M224.49,136.49l-72,72a12,12,0,0,1-17-17L187,140H40a12,12,0,0,1,0-24H187L135.51,64.48a12,12,0,0,1,17-17l72,72A12,12,0,0,1,224.49,136.49Z"></path>
				</svg>
				</button>
			</div>
		</div>
		</main>
		<footer class="py-8 text-center border-t border-solid border-t-[var(--border-color)] bg-slate-50">
		<p class="text-sm text-[var(--text-secondary)]">© 2025 EduQuest.</p>
		</footer>
	</div>
</div>
</body>
</html>