<div class="max-w-4xl mx-auto">
    <div class="mb-8">
        <h2 class="text-3xl font-bold text-[var(--text-primary)]">Materi Bahasa Inggris Kelas 10</h2>
        <p class="text-[var(--text-secondary)] mt-2">Pilih bab untuk memulai pembelajaran Anda.</p>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <a href="/chapter/1" class="chapter-card bg-white rounded-xl shadow-lg p-6 group transition-all duration-300">
            <div class="flex items-center mb-4">
                <div class="bg-blue-100 text-[var(--primary-color)] flex justify-center items-center size-12 rounded-lg mr-4">
                    <span class="material-icons text-3xl">auto_stories</span>
                </div>
                <div>
                    <h3 class="text-lg font-semibold group-hover:text-[var(--primary-color)]">Chapter 1</h3>
                    <p class="text-sm text-[var(--text-secondary)]">Great Athletes</p>
                </div>
            </div>
            <p class="text-sm text-[var(--text-secondary)] leading-relaxed">
                Deskripsi: Pelajari bagaimana menggambarkan atlet hebat menggunakan Descriptive Text dan memahami struktur serta nilai-nilai mereka.
            </p>
            <div class="mt-4 text-right text-sm text-[var(--primary-color)] group-hover:underline">
                Lihat Materi <span class="material-icons text-sm align-middle">arrow_forward</span>
            </div>
        </a>
    </div>
</div>