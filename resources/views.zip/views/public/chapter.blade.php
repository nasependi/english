@extends('layout.app') {{-- Ini akan meng-include app.blade.php --}}

@section('title', 'Chapter')

@section('content')
<div class="p-6">
	<h1 class="text-2xl font-bold mb-2">Daftar Chapter</h1>
	@foreach ($chapters as $chapter)
	<div class="p-4 border rounded mb-3">
		<h2 class="text-lg font-semibold">{{ $chapter->title }}</h2>
		<p class="text-gray-600">{{ $chapter->description }}</p>
	</div>
	@endforeach
</div>
@endsection